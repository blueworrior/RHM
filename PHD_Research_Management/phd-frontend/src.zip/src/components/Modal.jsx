import React from "react";
import { X } from 'lucide-react';

const Modal = ({ isOpen, onClose, title, children }) => {
    if(!isOpen) return null;

    return(
        <div className="modal-overlay">
            <div className="modal">
                <div className="modal-header">
                    <h2>{title}</h2>
                    <button onClick={onClose} className="modal-close">
                        <X size={24} />
                    </button>
                </div>
                <div className="modal-body">
                    {children}
                </div>
            </div>
        </div>
    );
};

export default Modal;